/**
 * The package PropertyChecker.
 */
package edu.pse.beast.zzz.propertychecker;
