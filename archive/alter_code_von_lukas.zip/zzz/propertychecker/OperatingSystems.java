package edu.pse.beast.zzz.propertychecker;

/**
 * The Enum OperatingSystems.
 *
 * @author Lukas Stapelbroek
 */
public enum OperatingSystems {
    /**
     * All Linux OS.
     */
    Linux,

    /**
     * T.
     */
    Windows,

    /**
     * MacOS.
     */
    Mac
}
