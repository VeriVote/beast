/**
 * The package JNA.
 */
package edu.pse.beast.zzz.propertychecker.jna;
