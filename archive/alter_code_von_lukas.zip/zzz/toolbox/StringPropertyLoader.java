package edu.pse.beast.zzz.toolbox;

//public class StringPropertyLoader {
//
//  private String currentLanguage = "en";
//
//}
