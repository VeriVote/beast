/**
 * The package ElectionSimulator.
 */
package edu.pse.beast.zzz.electionsimulator;
