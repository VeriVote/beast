/**
 * The package View.
 */
package edu.pse.beast.zzz.electionsimulator.view;
