/**
 * The package UserActions.
 */
package edu.pse.beast.zzz.electionsimulator.useractions;
