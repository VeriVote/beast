/**
 * The package Model.
 */
package edu.pse.beast.zzz.electionsimulator.model;
