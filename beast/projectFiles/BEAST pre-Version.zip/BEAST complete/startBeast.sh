#!/bin/sh

cd core
java -jar BEAST.jar