#include <stdlib.h>
#include <stdint.h>
#include <assert.h>

unsigned int nondet_uint();
int nondet_int();

#define assert2(x, y) __CPROVER_assert(x, y)
#define assume(x) __CPROVER_assume(x)

struct result { unsigned int arr[S]; };
struct stack_result { unsigned int arr[C]; };
struct vote_single { unsigned int arr[V]; };
struct vote_double { unsigned int arr[V][C]; };
struct candidateList_result { unsigned int arr[C]; };
unsigned int voteSumForCandidate(unsigned int arr[V][C], unsigned int amountVotes, unsigned int candidate) {
		unsigned int sum = 0;
		for(unsigned int i = 0; i < amountVotes; i++) {
				if(arr[i][0] == candidate) sum++;
		}
		return sum;
}
unsigned int voteSumForCandidateUnique(unsigned int arr[V][C], unsigned int amountVotes, unsigned int candidate) {
		unsigned int sum = 0;
		for(unsigned int i = 0; i < amountVotes; i++) {
				if(arr[i][0] == candidate) sum++;
		}
		return sum;
}
//split array

//get splits cuts through an array of size max
unsigned int *getRandomSplitLines(unsigned int splits, unsigned int max) {
		unsigned int *split_arr = malloc(splits * sizeof(*split_arr));
		
		if (splits == 1) {
				unsigned int next_split = nondet_uint();
				assume(next_split >= 0);
				assume(next_split <= (max / 2));
				
				split_arr[0] = next_split;
		} else {
				unsigned int last_split = 0;
				for (int i = 0; i < splits; i++) {
						
						unsigned int next_split = nondet_uint();
						assume(next_split >= last_split);
						assume(next_split <= max);
						
								
					unsigned int debugHier =max + 1;
						
						split_arr[i] = next_split;
						last_split = next_split;
				}
				
				unsigned int *splitLines;
				splitLines = split_arr;
				
				for (int i = 0; i < splits; i++) {
						unsigned int debugrandom = splitLines[i];
				}
		}
		return split_arr;
}

//start is inclusive, stop is exclusive
struct vote_single splitOne(unsigned int votes[V], unsigned int start, unsigned int stop) {
		static unsigned int sub_arr[V];
		
		for(int i = 0; i < V; i++) { //set all to C in the beginning
				sub_arr[i] = C;
		}
		
		if(start == stop) { //the sub array should be empty
				struct vote_single toReturn;
				
				for (int i = 0; i < V; i++) {
						toReturn.arr[i] = sub_arr[i];
				}
				
				return toReturn;
		} else {
		
				for (int i = 0; i < V; i++) {
						if ((i >= start) && (i < stop)) {
								sub_arr[i - start] = votes[i];
						}
				}
			
			//struct vote_single toReturn = {sub_arr};
				
				struct vote_single toReturn;
				
				for (int i = 0; i < V; i++) {
						toReturn.arr[i] = sub_arr[i];
				}
				
				return toReturn;
		}
}

//start is inclusive, stop is exclusive
//used for 2 dim arrays
struct vote_double splitTwo(unsigned int votes[V][C], unsigned int start, unsigned int stop) {
		static unsigned int sub_arr[V][C];
		
		for(int i = 0; i < V; i++) { //set all to C in the beginning
				for(int j = 0; j < C; j++) {
						sub_arr[i][j] = C;
				}
		}
		
		if(start == stop) { //the sub array should be empty
				struct vote_double toReturn;
				
				for (int i = 0; i < V; i++) {
						for(int j = 0; j < V; j++) {
								toReturn.arr[i][j] = sub_arr[i][j];
						}
				}
				
				return toReturn;
		} else {
		
				for (int i = 0; i < V; i++) {
						if ((i >= start) && (i < stop)) {
								for(int j = 0; j < C; j++) {
										sub_arr[i - start][j] = votes[i][j];
								}
						}
				}
				
				struct vote_double toReturn;
				
				for (int i = 0; i < V; i++) {
						for(int j = 0; j < V; j++) {
								toReturn.arr[i][j] = sub_arr[i][j];
						}
				}
				
				return toReturn;
		}
}

struct vote_single concatOne(unsigned int votesOne[V], unsigned int sizeOne, unsigned int votesTwo[V][C], unsigned int sizeTwo) {
		static unsigned int sub_arr[V];
		
		for(int i = 0; i < V; i++) { //set all to C in the beginning
				sub_arr[i] = C;
		}
		
		for(int i = 0; i < sizeOne; i++) { //limit the size to the upper bound V
				if (i < V) {
						sub_arr[i] = votesOne[i];
				}
		}
		
		for(int i = 0; i < sizeTwo; i++) { //limit the size to the upper bound V
				if (sizeOne + i < V) {
						sub_arr[sizeOne + i] = votesTwo[i];
				}
		}
		
		struct vote_single toReturn;
			
		for (int i = 0; i < V; i++) {
				toReturn.arr[i] = sub_arr[i];
		}
			
		return toReturn;
		
}

struct vote_double concatTwo(unsigned int votesOne[V][C], unsigned int sizeOne, unsigned int votesTwo[V][C], unsigned int sizeTwo) {
		static unsigned int sub_arr[V][C];
		
		for(int i = 0; i < V; i++) { //set all to C in the beginning
				for(int j = 0; j < C; j++) {
						sub_arr[i][j] = C;
				}
		}
		
		for(int i = 0; i < sizeOne; i++) { //limit the size to the upper bound V
				for(int j = 0; j < C; j++) {
						if (i < V) {
								sub_arr[i][j] = votesOne[i][j];
						}
				}
		}
		
		for(int i = 0; i < sizeTwo; i++) { //limit the size to the upper bound V
				for(int j = 0; j < C; j++) {
						if (sizeTwo + i < V) {
								sub_arr[i][j] = votesTwo[i][j];
						}
				}
		}
		
		struct vote_double toReturn;
			
		for (int i = 0; i < V; i++) {
				for (int j = 0; j < C; j++) {
						toReturn.arr[i][j] = sub_arr[i][j];
				}
		}
			
		return toReturn;
}
struct vote_single permutateOne(unsigned int votes[V], unsigned int length) {
		static unsigned int sub_arr[V];
		
		static unsigned int already_used_arr[V];
			
		for(int i = 0; i < V; i++) { //set all to C in the beginning
				sub_arr[i] = C;
		}
		
		
		for(int i = 0; i < length; i++) {
				unsigned int new_index = nondet_uint();
				assume((new_index >= 0) && (new_index < length));
				
				for(int j = 0; j < i; j++) {
						assume(new_index != already_used_arr[j]);
				}
				
				already_used_arr[i] = new_index;
				
				sub_arr[new_index] = votes[i];
		}
		
		struct vote_single toReturn;
			
		for (int i = 0; i < V; i++) {
				toReturn.arr[i] = sub_arr[i];
		}
			
		return toReturn;
		
}

struct vote_double permutateTwo(unsigned int votes[V][C], unsigned int length) {
		static unsigned int sub_arr[V][C];
		
		static unsigned int already_used_arr[V];
			
		for(int i = 0; i < V; i++) { //set all to C in the beginning
				for(int j = 0; j < C; j++) {
						sub_arr[i][j] = C;
				}
		}
		
		
		for(int i = 0; i < length; i++) {
				unsigned int new_index = nondet_uint();
				assume((new_index >= 0) && (new_index < length));
				
				for(int j = 0; j < i; j++) {
						assume(new_index != already_used_arr[j]);
				}
				
				already_used_arr[i] = new_index;
				
				for(int j = 0; j < i; j++) {
						sub_arr[new_index][j] = votes[i][j];
				}
		}
		
		struct vote_double toReturn;
			
		for (int i = 0; i < V; i++) {
				for(int j = 0; j < C; j++) {
						toReturn.arr[i][j] = sub_arr[i][j];
				}
		}
			
		return toReturn;
}
struct candidateList_result intersect(struct candidateList_result one, struct candidateList_result two) {
		static struct candidateList_result toReturn;
		
		for (int i = 0; i < C; i++) {
				toReturn.arr[i] = 0;
		}
		
		for (int i = 0; i < C; i++) {
				if (one.arr[i] && two.arr[i]) {
						toReturn.arr[i] = 1;
				}
		}
		
		return toReturn;
}
//Code of the user
struct candidateList_result voting(unsigned int votes[V][C]) {
		struct candidateList_result toReturn;
	
		for (int i = 0; i < C; i ++) {
				toReturn.arr[i] = 0;
		}
	
		return toReturn;
}
int main(int argc, char *argv[]) {
		unsigned int V1 = V;
		unsigned int V2 = V;
		unsigned int V3 = V;
		unsigned int C1 = C;
		unsigned int C2 = C;
		unsigned int C3 = C;
		unsigned int S1 = S;
		unsigned int S2 = S;
		unsigned int S3 = S;
		
		//Symbolic Variables initialisation
		
		//voting-array and elect variable initialisation
		//init for election: 1
		unsigned int votes1[V][C];
		for(unsigned int counter_0 = 0; counter_0 < V1; counter_0++){
				for(unsigned int counter_1 = 0; counter_1 < C1; counter_1++){
						votes1[counter_0][counter_1] = nondet_uint();
						assume((0 <= votes1[counter_0][counter_1]) && (votes1[counter_0][counter_1] < C1));
						for (unsigned int j_prime = 0; j_prime < counter_1; j_prime++) {
								assume (votes1[counter_0][counter_1] != votes1[counter_0][j_prime]);
						}
				}
		}
		
		//init for election: 2
		unsigned int votes2[V][C];
		for(unsigned int counter_0 = 0; counter_0 < V2; counter_0++){
				for(unsigned int counter_1 = 0; counter_1 < C2; counter_1++){
						votes2[counter_0][counter_1] = nondet_uint();
						assume((0 <= votes2[counter_0][counter_1]) && (votes2[counter_0][counter_1] < C2));
						for (unsigned int j_prime = 0; j_prime < counter_1; j_prime++) {
								assume (votes2[counter_0][counter_1] != votes2[counter_0][j_prime]);
						}
				}
		}
		
		//init for election: 3
		unsigned int votes3[V][C];
		for(unsigned int counter_0 = 0; counter_0 < V3; counter_0++){
				for(unsigned int counter_1 = 0; counter_1 < C3; counter_1++){
						votes3[counter_0][counter_1] = nondet_uint();
						assume((0 <= votes3[counter_0][counter_1]) && (votes3[counter_0][counter_1] < C3));
						for (unsigned int j_prime = 0; j_prime < counter_1; j_prime++) {
								assume (votes3[counter_0][counter_1] != votes3[counter_0][j_prime]);
						}
				}
		}
		
		
		//preproperties 
		
		unsigned int tmp_vote0[V][C];
		unsigned int tmp_size1;
		unsigned int tmp_vote2[V][C];
		unsigned int tmp_size3;
		unsigned int tmp_vote4[V][C];
		unsigned int tmp_size5;
		for(int i = 0; i < V; i++) {
					for(int j = 0; j < C; j++) {
						tmp_vote4[i][j] = votes1[i][j];
					}
		}
		tmp_size5 = V1;
		struct vote_double tmp6 = permutateTwo(tmp_vote4, tmp_size5);
		for(int i = 0; i < V; i++) {
				for(int j = 0; j < C; j++) {
						tmp_vote2[i][j] = tmp6.arr[i][j];
				}
		}
		tmp_size3 = tmp_size5;
		for(int i = 0; i < V; i++) {
					for(int j = 0; j < C; j++) {
						tmp_vote0[i][j] = tmp_vote2[i][j];
					}
		}
		tmp_size1 = tmp_size3;
		unsigned int splits7 = 1;
		unsigned int *splitLines8;
		splitLines8 = getRandomSplitLines(splits7, tmp_size1);
		unsigned int last_split9 = 0;
		struct vote_double tmp10 = splitTwo( tmp_vote0, last_split9, splitLines8[0]);
		for(int i = 0; i < V; i++) {
					for(int j = 0; j < C; j++) {
							votes2[i][j] = tmp10.arr[i][j];
					}
		}
		last_split9 = splitLines8[0];
		struct vote_double tmp11 = splitTwo( tmp_vote0, last_split9, tmp_size1);
		for(int i = 0; i < V; i++) {
					for(int j = 0; j < C; j++) {
							votes3[i][j] = tmp11.arr[i][j];
					}
		}
		//election number: 1
		struct candidateList_result tmp1 = voting(votes1);
		struct candidateList_result elect1;
		for (int electLoop = 0; electLoop < C; electLoop++) {
				elect1.arr[electLoop] = tmp1.arr[electLoop];
		}
		//election number: 2
		struct candidateList_result tmp2 = voting(votes2);
		struct candidateList_result elect2;
		for (int electLoop = 0; electLoop < C; electLoop++) {
				elect2.arr[electLoop] = tmp2.arr[electLoop];
		}
		//election number: 3
		struct candidateList_result tmp3 = voting(votes3);
		struct candidateList_result elect3;
		for (int electLoop = 0; electLoop < C; electLoop++) {
				elect3.arr[electLoop] = tmp3.arr[electLoop];
		}
		
		//postproperties 
		
		unsigned int not_empty12;
		unsigned int tmp_bool13 = 0;
		struct candidateList_result tmp_elect14;
		struct candidateList_result tmp_elect15;
		struct candidateList_result tmp_elect16;
		struct candidateList_result tmp_elect17;
		tmp_elect17 = elect2;
		for(int i = 0; i < C; i++) {
				tmp_elect15.arr[i] = tmp_elect17.arr[i];
		}
		struct candidateList_result tmp_elect18;
		tmp_elect18 = elect3;
		for(int i = 0; i < C; i++) {
				tmp_elect16.arr[i] = tmp_elect18.arr[i];
		}
		tmp_elect14 = intersect(tmp_elect15, tmp_elect16);
		for(int i = 0; i < C; i++) { 
				tmp_bool13 += tmp_elect14.arr[i];
		}
		not_empty12 = tmp_bool13;
		//comparison left side
		//comparison right side:
		struct candidateList_result tmp_elect19;
		struct candidateList_result tmp_elect20;
		struct candidateList_result tmp_output21;
		struct candidateList_result tmp_elect22;
		tmp_elect22 = elect2;
		for(int i = 0; i < C; i++) {
				tmp_elect19.arr[i] = tmp_elect22.arr[i];
		}
		struct candidateList_result tmp_elect23;
		tmp_elect23 = elect3;
		for(int i = 0; i < C; i++) {
				tmp_elect20.arr[i] = tmp_elect23.arr[i];
		}
		tmp_output21 = intersect(tmp_elect19, tmp_elect20);
		unsigned int comparison_0 = 1;
		for(unsigned int count_0 = 0; comparison_0 && count_0 < V; ++count_0) {
				comparison_0 = elect1.arr[count_0] == tmp_output21.arr[count_0];
		}
		unsigned int implication_0 = (!(not_empty12) || (comparison_0));
		assert(implication_0);
}
